//
//  FunctionsPattern5Protocol.swift
//  SampleCode
//
//  Created by Kazuhiro Hayashi on 2021/02/14.
//  
//

import Foundation

protocol FunctionsPattern5Protocol {
    func func1() -> String
    func func1()
    func func2()
    func func3() -> Void
    func func4() -> ()
}



