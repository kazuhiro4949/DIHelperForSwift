//
//  ClassSamples.swift
//  SampleCode
//
//  Created by Kazuhiro Hayashi on 2021/02/14.
//  
//

import Foundation

class Class {
    
}

class InheritedClass: NSObject {
    
}

@objc class ObjcClass: NSObject {
    
}
