//
//  FunctionClass.swift
//  SampleCode
//
//  Created by Kazuhiro Hayashi on 2021/02/14.
//  
//

import Foundation

class FunctionClass {
    func func1() {
        
    }
    
    func func2(arg: Int) {
        
    }
    
    
    func func3(arg: Int, arg2: String, arg3: () -> Void, arg4: (String, String)) {
        
    }
    
    
    func func4() -> String {
        ""
    }
    
    
    func func5() throws -> String {
        ""
    }
}
